import 'package:daftar_ktp/data/repositories/ktp_repository.dart';

class GetProvinceUseCase {
  final KtpRepository repository = KtpRepository();

  Future<List<String>> call() async {
    var listProvinces = await repository.getProvinces();
    var listProvinceNames = listProvinces.map((e) => e.name).toList();
    return listProvinceNames;
  }
}
