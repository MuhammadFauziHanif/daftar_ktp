import 'package:daftar_ktp/data/repositories/ktp_repository.dart';

class GetRegeciesUseCase {
  final KtpRepository repository = KtpRepository();

  Future<List<String>> call() async {
    var listRegencies = await repository.getRegencies();
    var listRegencyNames = listRegencies.map((e) => e.name).toList();
    return listRegencyNames;
  }
}
