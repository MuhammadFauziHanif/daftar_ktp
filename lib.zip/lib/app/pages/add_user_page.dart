import 'package:daftar_ktp/domain/usecases/get_provinces_usecase.dart';
import 'package:daftar_ktp/domain/usecases/get_regencies_usecase.dart';
import 'package:daftar_ktp/main.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:hive/hive.dart';

final List<String> _regencies = ['Regency A', 'Regency B', 'Regency C'];
final List<String> _provinces = ['Province X', 'Province Y', 'Province Z'];
final List<String> _occupations = ['Swasta', 'PNS', 'Wirausaha'];
final List<String> _educations = ['S1', 'S2', 'S3'];

class AddUserPage extends StatefulWidget {
  @override
  _AddUserPageState createState() => _AddUserPageState();
}

class _AddUserPageState extends State<AddUserPage> {
  late List<String> _regencies;
  late List<String> _provinces;
  late String _selectedRegency;
  late String _selectedProvince;

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  _fetchData() async {
    final getRegenciesUseCase = GetRegeciesUseCase();
    final getProvincesUseCase = GetProvinceUseCase();

    final regencies = await getRegenciesUseCase.call();
    final provinces = await getProvincesUseCase.call();

    _regencies = regencies;
    _provinces = provinces;
    _selectedRegency = regencies.first;
    _selectedProvince = provinces.first;
  }

  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _birthPlaceController = TextEditingController();
  String _selectedOccupation = _occupations.first;
  String _selectedEducation = _educations.first;

  void _saveUser() {
    final User user = User(
      name: _nameController.text,
      birthPlace: _birthPlaceController.text,
      regency: _selectedRegency,
      province: _selectedProvince,
      occupation: _selectedOccupation,
      education: _selectedEducation,
    );

    context.read<UserBloc>().addUser(user);
    // go back to home screen
    context.go('/');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tambah Pengguna'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: 'Nama'),
            ),
            TextField(
              controller: _birthPlaceController,
              decoration: InputDecoration(labelText: 'Tempat Tanggal Lahir'),
            ),
            DropdownButton<String>(
              value: _selectedRegency,
              onChanged: (value) {
                setState(() {
                  _selectedRegency = value!;
                });
              },
              items: _regencies.map((regency) {
                return DropdownMenuItem<String>(
                  value: regency,
                  child: Text(regency),
                );
              }).toList(),
              hint: Text('Pilih Kabupaten'),
            ),
            DropdownButton<String>(
              value: _selectedProvince,
              onChanged: (value) {
                setState(() {
                  _selectedProvince = value!;
                });
              },
              items: _provinces.map((province) {
                return DropdownMenuItem<String>(
                  value: province,
                  child: Text(province),
                );
              }).toList(),
              hint: Text('Pilih Provinsi'),
            ),
            DropdownButton<String>(
              value: _selectedOccupation,
              onChanged: (value) {
                setState(() {
                  _selectedOccupation = value!;
                });
              },
              items: _occupations.map((occupation) {
                return DropdownMenuItem<String>(
                  value: occupation,
                  child: Text(occupation),
                );
              }).toList(),
              hint: Text('Pilih Pekerjaan'),
            ),
            DropdownButton<String>(
              value: _selectedEducation,
              onChanged: (value) {
                setState(() {
                  _selectedEducation = value!;
                });
              },
              items: _educations.map((education) {
                return DropdownMenuItem<String>(
                  value: education,
                  child: Text(education),
                );
              }).toList(),
              hint: Text('Pilih Pendidikan'),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                _saveUser();
              },
              child: Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }
}
